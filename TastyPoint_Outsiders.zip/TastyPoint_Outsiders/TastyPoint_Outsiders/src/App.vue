<template>
  <div>
    <DashBoard></DashBoard>
  </div>
  <RouterView />
</template>

<script>

export default{

  data(){
    return{
        
    }
  }
}
</script>

<style scoped>

</style>