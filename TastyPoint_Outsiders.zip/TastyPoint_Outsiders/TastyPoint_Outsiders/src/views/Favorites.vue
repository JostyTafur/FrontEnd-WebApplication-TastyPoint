<template>
    <div class="favorites">
        <p>Favorites</p>
    </div>
</template>

<script>
export default{

}
</script>

<style scoped>
    .favorites{
        display: flex;
        justify-content: center;
        align-items: center;
    }
</style>