<template>
    <div class="settings">
        <p>Settings</p>
    </div>
</template>

<script>
export default{

}
</script>

<style scoped>
    .settings{
        display: flex;
        justify-content: center;
        align-items: center;
    }
</style>