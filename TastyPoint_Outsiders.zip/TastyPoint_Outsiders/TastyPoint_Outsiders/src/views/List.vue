<template>

    <div class="list">
      <div>
        <div class="container">
          <input type="text" placeholder="Search food dishes, suppliers or restaurants">
          <div class="btn">
            <p>Search</p>
          </div>
        </div>
      </div>
      <div>
        <div class="container-card">

          <div class="card">
            <figure>
              <img src="https://www.diariamenteali.com/medias/receta-de-papas-sancochadas-con-aroma-de-pachamanca-1900Wx500H?context=bWFzdGVyfGltYWdlc3wyMjEwMTd8aW1hZ2UvanBlZ3xoOTYvaGZhLzkwNzQxMzAxNTc1OTgvcmVjZXRhLWRlLXBhcGFzLXNhbmNvY2hhZGFzLWNvbi1hcm9tYS1kZS1wYWNoYW1hbmNhXzE5MDBXeDUwMEh8NTM3MTJiMzI2YmQ2OTAyY2UzOGNkNDFlNTIxZTg4ZmRmZWVhMDE5OWM2YmI0Y2I1NmE4ZDNmYmRkZTg2Yzc1Nw">
            </figure>
            <div class="contenido-card">
              <a href="#">Restaurant: 7 Sopas</a>
              <p>Product type: Supplies</p>
              <p>Product name: Parboiled</p>
              <p>Description: Boiled potatoes left over from the preparation of  a soup  of the day</p>
              <p>Delivery methods:</p>
              <p>Face-to-face</p>
              <p>This store does not offer delivery</p>
            </div>
          </div>
          <div class="card">
            <div class="contenido-card">
              <h3>Make an order: </h3>
              <form>
                <label for = "Quantity:">Quantity</label>
                <input id = "Quantity:"> type = "text" name ="surname">
              </form>

              <p>Nosotros creamos y optimizamos tus perfiles en las Redes Sociales. Importantes para que tu presencia online sea completa.</p>
              <a href="#  "> Cancel</a>
              <a href="#  ">Pay and finishis</a>
            </div>
          </div>

        </div>
      </div>
    </div>

</template>

<script>
export default{
    name: "List",
    data(){
        return {
            clicked: true
                
        }
    }
}
</script>

<style scoped>
    .title{
       margin: 00px
    }
    .list{
        display: grid;
        justify-content: start;
        text-align:center;
    }
    .cards{
        margin: 00px;
        display: flex;
        justify-content: center;
    }


    .container {
        margin: 20px;
    }

    input {
      outline: none;
      box-sizing: border-box;
      height: 60px;
      width: 0px;
      padding: 0 10px;
      color: #000;
      border-radius: 30px;
      font-size: 20px;
      border: 2px solid #D50000;
      transition: all .7s ease;
    }

    ::placeholder {
      color: grey;
    }

    .btn {
      position: absolute;
      right: -10px;
      top: 0px;
      width: 70px;
      height: 60px;
      background: #D50000;
      line-height: 70px;
      border-radius: 50%;
      text-align: center;
      cursor: pointer;
      transition: .7s;
    }

    .btn p {
      font-size: 10px;
      color: white;
      line-height: 200px;
      transition: all .7s ease;
    }

    .container input {
      width: 1450px;
    }

    .container:hover i{
      transform: rotate(-360deg);
    }

    .btn:hover{
      background: black;
    }
    .container-card{
      width: 100%;
      display: flex;
      max-width: 1450px;
      margin: auto;
    }
    .title-cards{
      width: 100%;
      max-width: 1080px;
      margin: auto;
      padding: 100px;
      margin-top: 30px;
      text-align: center;
      color: black;
    }
    .card{
      width: 100%;
      margin: 60px;
      border-radius: 29px;
      overflow: hidden;
      background:white;
      box-shadow: 0px 1px 80px rgba(0,0,0,0.2);
      transition: all 400ms ease-out;
      cursor: default;
    }
    .card:hover{
      box-shadow: 15px 15px 80px rgba(0,0,0,0.4);
      transform: translateY(-3%);
    }
    .card img{
      width: 100%;
      height: 330px;
    }
    .card .contenido-card{
      padding: 50px;
      text-align:center;
    }
    .card .contenido-card h3{
      margin-bottom: 70px;
      color: black;
    }
    .card .contenido-card p{
      line-height: 1.3;
      color: brown;
      font-size: 18px;
      margin-bottom: 5px;
    }
    .card .contenido-card a{
      display: inline-block;
      padding: 10px;
      margin-top: 10px;
      text-decoration: none;
      color: saddlebrown;
      border: 1px solid sandybrown;
      border-radius: 10px;
      transition: all 400ms ease;
      margin-bottom: 40px;
    }
    .card .contenido-card a:hover{
      background: brown;
      color: #fff;
    }
    @media only screen and (min-width:320px) and (max-width:768px){
      .container-card{
        flex-wrap: wrap;
      }
      .card{
        margin: 30px;
      }
    }


</style>