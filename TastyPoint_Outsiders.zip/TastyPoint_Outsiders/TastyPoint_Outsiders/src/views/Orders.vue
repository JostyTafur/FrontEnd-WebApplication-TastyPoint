<template>
    <div class="orders">
        <p>Orders</p>
    </div>
</template>

<script>
export default{

}
</script>

<style scoped>
    .orders{
        display: flex;
        justify-content: center;
        align-items: center;
    }
</style>