<template>
    <div class="login">
        <p>Login</p>
    </div>
</template>

<script>
export default{

}
</script>

<style scoped>
    .Login{
        display: flex;
        justify-content: center;
        align-items: center;
    }
</style>