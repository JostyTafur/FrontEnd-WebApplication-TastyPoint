<template>
    <div class="notifications">
        <p>Notifications</p>
    </div>
</template>

<script>
export default{

}
</script>

<style scoped>
    .notifications{
        display: flex;
        justify-content: center;
        align-items: center;
    }
</style>